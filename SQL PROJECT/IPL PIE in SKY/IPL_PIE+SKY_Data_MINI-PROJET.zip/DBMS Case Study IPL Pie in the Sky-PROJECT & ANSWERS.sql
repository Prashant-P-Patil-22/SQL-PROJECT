# DBMS Case Study IPL Pie in the Sky-PROJECT & PRASENTATION:

use ipl;
show tables;
select * from ipl_bidder_details;
select * from ipl_bidder_points;
select * from ipl_bidding_details;
select * from ipl_match;
select * from ipl_match_schedule;
select * from ipl_player;
select * from ipl_stadium;
select * from ipl_team;
select * from ipl_team_players;
select * from ipl_team_standings;
select * from ipl_tournament;
select * from ipl_user;

# 1. Show the percentage of wins of each bidder in the order of highest to lowest percentage.

select * from ipl_bidder_details;
select * from ipl_bidder_points;
select * from ipl_bidding_details;

SELECT A.BIDDER_ID,A.BIDDER_NAME,
(SELECT COUNT(BIDDER_ID) 
FROM IPL_BIDDING_DETAILS B 
WHERE B.BID_STATUS='LOST' AND A.BIDDER_ID = B.BIDDER_ID)/
(SELECT NO_OF_BIDS 
FROM IPL_BIDDER_POINTS C 
WHERE A.BIDDER_ID = C.BIDDER_ID)*100 AS 'LOST_PERCENTAGE'
FROM IPL_BIDDER_DETAILS A
ORDER BY LOST_PERCENTAGE DESC;

# 2.Display the number of matches conducted at each stadium with stadium name, city from the database.

SELECT A.STADIUM_ID,A.STADIUM_NAME,A.CITY,
COUNT(B.STADIUM_ID) AS MATCHES_IN_EACH_STADIUM 
FROM IPL_STADIUM A
LEFT JOIN IPL_MATCH_SCHEDULE B ON A.STADIUM_ID = B.STADIUM_ID
GROUP BY A.STADIUM_ID
ORDER BY STADIUM_NAME;

# 3.In a given stadium, what is the percentage of wins by a team which has won the toss?

SELECT A.STADIUM_ID,A.STADIUM_NAME,CITY,
(SELECT COUNT(*) 
FROM IPL_MATCH B 
JOIN IPL_MATCH_SCHEDULE C ON B.MATCH_ID = C.MATCH_ID
WHERE B.TOSS_WINNER = B.MATCH_WINNER
AND C.STADIUM_ID=A.STADIUM_ID)/
(SELECT COUNT(*) 
FROM IPL_MATCH_SCHEDULE C 
WHERE C.STADIUM_ID = A.STADIUM_ID)*100 AS 'WIN_PERCENTAGE'
FROM IPL_STADIUM A;

# 4. Show the total bids along with bid team and team name.

select * from ipl_bidding_details;
select * from ipl_team;

SELECT A.BID_TEAM,B.TEAM_NAME,
COUNT(A.BID_TEAM) AS TOTAL_BIDS
FROM IPL_BIDDING_DETAILS A
JOIN IPL_TEAM B
ON A.BID_TEAM = B.TEAM_ID
GROUP BY A.BID_TEAM
ORDER BY A.BID_TEAM;
  
# 5.Show the team id who won the match as per the win details.

SELECT TEAM_ID, TEAM_NAME, TEAM_ID1, TEAM_ID2, MATCH_WINNER,IPL_MATCH.WIN_DETAILS
FROM IPL_TEAM
INNER JOIN IPL_MATCH
ON SUBSTR(IPL_TEAM.REMARKS,1,3) = SUBSTR(IPL_MATCH.WIN_DETAILS,6,3);

# 6.Display total matches played, total matches won and total matches lost by team along with its team name.

SELECT A.TEAM_ID,B.TEAM_NAME,
SUM(A.MATCHES_PLAYED) AS TOTAL_MATCHES_PLAYED,
SUM(A.MATCHES_WON) AS WON,
SUM(A.MATCHES_LOST) AS LOST 
FROM IPL_TEAM_STANDINGS A
JOIN IPL_TEAM B
ON A.TEAM_ID = B.TEAM_ID
GROUP BY A.TEAM_ID;

# 7. Display the bowlers for Mumbai Indians team.

select * from ipl_team;
select * from ipl_team_players;
# METHOD 1
select*FROM ipl_team_players where TEAM_ID = '5' and PLAYER_ROLE ='Bowler';
# METHOD 2
SELECT A.PLAYER_ID,B.PLAYER_NAME,A.PLAYER_ROLE,C.TEAM_NAME
FROM IPL_TEAM_PLAYERS A
JOIN IPL_PLAYER B 
ON A.PLAYER_ID = B.PLAYER_ID 
JOIN IPL_TEAM C
ON A.TEAM_ID = C.TEAM_ID 
WHERE A.PLAYER_ROLE = 'BOWLER' 
and C.TEAM_NAME='Mumbai Indians';

# 8.How many all-rounders are there in each team, Display the teams with more than 4 all-rounder in descending order.

select * from ipl_team_players;
select * from ipl_player;
select * from ipl_team;

SELECT C.TEAM_NAME,A.PLAYER_ROLE,
COUNT(A.PLAYER_ROLE) AS COUNT
FROM IPL_TEAM_PLAYERS A
JOIN IPL_PLAYER B ON A.PLAYER_ID=B.PLAYER_ID 
JOIN IPL_TEAM C ON A.TEAM_ID=C.TEAM_ID 
WHERE A.PLAYER_ROLE = 'ALL-ROUNDER' 
GROUP BY C.TEAM_NAME
HAVING COUNT >4
ORDER BY COUNT DESC;
